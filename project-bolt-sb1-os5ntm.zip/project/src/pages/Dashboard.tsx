import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  DollarSign,
  Activity,
  Link as LinkIcon,
  Copy,
  Wallet,
  ChevronRight
} from 'lucide-react';

const StatCard = ({ icon: Icon, title, value, trend }) => (
  <div className="bg-white rounded-xl p-6 shadow-lg">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-gray-500 text-sm">{title}</p>
        <h3 className="text-2xl font-bold mt-1">{value}</h3>
      </div>
      <div className="bg-indigo-100 p-2 rounded-lg">
        <Icon className="h-6 w-6 text-indigo-600" />
      </div>
    </div>
    {trend && (
      <div className="mt-2 flex items-center text-sm">
        <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
        <span className="text-green-500">{trend}</span>
      </div>
    )}
  </div>
);

const RecentActivity = ({ type, name, amount, time }) => (
  <div className="flex items-center justify-between py-3">
    <div className="flex items-center">
      <div className="bg-indigo-100 p-2 rounded-lg mr-4">
        <Activity className="h-5 w-5 text-indigo-600" />
      </div>
      <div>
        <p className="font-medium">{name}</p>
        <p className="text-sm text-gray-500">{type}</p>
      </div>
    </div>
    <div className="text-right">
      <p className="font-medium">₹{amount}</p>
      <p className="text-sm text-gray-500">{time}</p>
    </div>
  </div>
);

const Dashboard = () => {
  const profileUrl = 'creatorsjar.com/alexrivera';

  const copyToClipboard = () => {
    navigator.clipboard.writeText(profileUrl);
    // Add toast notification here
  };

  return (
    <div className="min-h-screen pt-20 pb-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back, Alex Rivera</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={Users}
            title="Total Supporters"
            value="1,234"
            trend="+12% this month"
          />
          <StatCard
            icon={DollarSign}
            title="Total Earnings"
            value="₹45,678"
            trend="+8% this month"
          />
          <StatCard
            icon={Activity}
            title="Page Views"
            value="5,678"
            trend="+15% this month"
          />
          <StatCard
            icon={LinkIcon}
            title="Link Clicks"
            value="892"
            trend="+5% this month"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold mb-6">Recent Activity</h2>
              <div className="divide-y">
                <RecentActivity
                  type="New Support"
                  name="John Doe"
                  amount="500"
                  time="2 hours ago"
                />
                <RecentActivity
                  type="Page View"
                  name="Anonymous"
                  amount="0"
                  time="3 hours ago"
                />
                <RecentActivity
                  type="New Support"
                  name="Jane Smith"
                  amount="1,000"
                  time="5 hours ago"
                />
              </div>
              <button className="mt-6 text-indigo-600 hover:text-indigo-700 font-medium flex items-center">
                View all activity
                <ChevronRight className="h-4 w-4 ml-1" />
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6 space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-4">Your Profile Link</h2>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={profileUrl}
                    readOnly
                    className="input-field bg-gray-50"
                  />
                  <button
                    onClick={copyToClipboard}
                    className="p-2 text-gray-500 hover:text-indigo-600"
                  >
                    <Copy className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
                <div className="space-y-3">
                  <button className="w-full btn-primary justify-center">
                    <Wallet className="h-5 w-5 mr-2" />
                    Withdraw Funds
                  </button>
                  <button className="w-full border border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-indigo-600 hover:text-indigo-600 transition-colors flex items-center justify-center">
                    <LinkIcon className="h-5 w-5 mr-2" />
                    Update Profile
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
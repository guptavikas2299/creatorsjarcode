import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Camera } from 'lucide-react';

const Register = () => {
  const [profileImage, setProfileImage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-2xl shadow-xl p-8"
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Join Creator's Jar</h1>
            <p className="mt-2 text-gray-600">Start receiving support from your community</p>
          </div>

          <form className="space-y-6">
            {/* Profile Image Upload */}
            <div className="flex flex-col items-center">
              <div className="relative">
                <div className={`w-32 h-32 rounded-full flex items-center justify-center border-2 border-dashed border-gray-300 overflow-hidden ${profileImage ? 'border-none' : ''}`}>
                  {profileImage ? (
                    <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <label htmlFor="profile-image" className="absolute bottom-0 right-0 bg-indigo-600 rounded-full p-2 cursor-pointer hover:bg-indigo-700 transition-colors">
                  <Upload className="w-4 h-4 text-white" />
                  <input
                    type="file"
                    id="profile-image"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </label>
              </div>
              <p className="mt-2 text-sm text-gray-500">Upload profile picture</p>
            </div>

            {/* Creator Page Name */}
            <div>
              <label htmlFor="page-name" className="block text-sm font-medium text-gray-700">
                Creator Page Name
              </label>
              <input
                type="text"
                id="page-name"
                className="mt-1 input-field"
                placeholder="Your creative space name"
              />
            </div>

            {/* Username */}
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700">
                Username
              </label>
              <div className="mt-1 flex rounded-lg shadow-sm">
                <span className="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-gray-200 bg-gray-50 text-gray-500 sm:text-sm">
                  creatorsjar.com/
                </span>
                <input
                  type="text"
                  id="username"
                  className="flex-1 input-field rounded-none rounded-r-lg"
                  placeholder="yourname"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                type="email"
                id="email"
                className="mt-1 input-field"
                placeholder="you@example.com"
              />
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <input
                type="password"
                id="password"
                className="mt-1 input-field"
                placeholder="••••••••"
              />
            </div>

            {/* Creator Type */}
            <div>
              <label htmlFor="creator-type" className="block text-sm font-medium text-gray-700">
                Creator Type
              </label>
              <select id="creator-type" className="mt-1 input-field">
                <option value="">Select your creator type</option>
                <option value="artist">Artist</option>
                <option value="writer">Writer</option>
                <option value="content-creator">Content Creator</option>
                <option value="coder">Coder</option>
                <option value="musician">Musician</option>
                <option value="other">Other</option>
              </select>
            </div>

            {/* Social Link */}
            <div>
              <label htmlFor="social-link" className="block text-sm font-medium text-gray-700">
                Main Social Media Link (Optional)
              </label>
              <input
                type="url"
                id="social-link"
                className="mt-1 input-field"
                placeholder="https://..."
              />
            </div>

            {/* Submit Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full btn-primary justify-center py-4"
            >
              Create Your Creator Page
            </motion.button>
          </form>

          <p className="mt-6 text-center text-sm text-gray-500">
            Already have an account?{' '}
            <a href="/login" className="text-indigo-600 hover:text-indigo-700 font-medium">
              Log in
            </a>
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Register;
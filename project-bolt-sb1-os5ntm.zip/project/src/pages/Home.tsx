import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Hero from '../components/Hero';
import { Palette, Code, Video, Pen, Music, Heart } from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5 }}
      className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
    >
      <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
        <Icon className="h-6 w-6 text-indigo-600" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  );
};

const ReviewCard = ({ name, role, image, comment }) => (
  <div className="bg-white p-6 rounded-xl shadow-lg mx-4">
    <div className="flex items-center mb-4">
      <img
        src={image}
        alt={name}
        className="w-12 h-12 rounded-full object-cover"
      />
      <div className="ml-4">
        <h4 className="font-semibold">{name}</h4>
        <p className="text-gray-600 text-sm">{role}</p>
      </div>
    </div>
    <p className="text-gray-700">{comment}</p>
  </div>
);

const Home = () => {
  const features = [
    {
      icon: Palette,
      title: "For Artists",
      description: "Share your artwork and receive support from your community.",
    },
    {
      icon: Code,
      title: "For Developers",
      description: "Get funded for your open-source contributions and projects.",
    },
    {
      icon: Video,
      title: "For Content Creators",
      description: "Monetize your content directly through your loyal audience.",
    },
    {
      icon: Pen,
      title: "For Writers",
      description: "Turn your words into sustainable income with reader support.",
    },
    {
      icon: Music,
      title: "For Musicians",
      description: "Let your fans support your musical journey directly.",
    },
    {
      icon: Heart,
      title: "For All Creators",
      description: "Build meaningful connections with your supporters.",
    },
  ];

  const reviews = [
    {
      name: "Sarah Chen",
      role: "Digital Artist",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
      comment: "Creator's Jar has transformed how I connect with my supporters. The platform is intuitive and the community is amazing!",
    },
    {
      name: "Alex Rivera",
      role: "Tech Content Creator",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
      comment: "The seamless donation process and beautiful profile pages make it easy for my audience to support my work.",
    },
    {
      name: "Emily Thompson",
      role: "Indie Musician",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
      comment: "Finally, a platform that puts creators first! The dashboard analytics help me understand my growth.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Hero />

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Empowering Every Type of Creator
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Join our diverse community of creators and start receiving support for your work
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              What Creators Are Saying
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Join thousands of creators who have found success with Creator's Jar
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <ReviewCard key={index} {...review} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Heart, Coffee, Gift } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative overflow-hidden pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10"
        >
          <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 mb-8">
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Empower Creators,
            </span>
            <br />
            One Donation at a Time
          </h1>
          <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
            Support your favorite creators directly and help them continue making the content you love.
          </p>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <a
              href="#featured-creators"
              className="inline-flex items-center px-8 py-4 rounded-full text-lg font-semibold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Explore Creators
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </motion.div>
        </motion.div>

        {/* Floating Elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              y: [0, -20, 0],
              rotate: [0, 10, 0],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4"
          >
            <Heart className="h-12 w-12 text-pink-400 opacity-50" />
          </motion.div>
          <motion.div
            animate={{
              y: [0, 20, 0],
              rotate: [0, -10, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1,
            }}
            className="absolute top-1/3 right-1/4"
          >
            <Coffee className="h-12 w-12 text-amber-400 opacity-50" />
          </motion.div>
          <motion.div
            animate={{
              y: [-20, 0, -20],
              rotate: [10, 0, 10],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2,
            }}
            className="absolute bottom-1/4 right-1/3"
          >
            <Gift className="h-12 w-12 text-indigo-400 opacity-50" />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Hero;